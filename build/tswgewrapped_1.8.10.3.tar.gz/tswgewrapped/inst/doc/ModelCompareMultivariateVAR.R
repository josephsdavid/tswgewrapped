## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(tswgewrapped)

## ------------------------------------------------------------------------
file = system.file("extdata", "USeconomic.csv", package = "tswgewrapped", mustWork = TRUE)
data = read.csv(file, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
names(data) = gsub("[(|)]", "", colnames(data))

## ------------------------------------------------------------------------
lag.max = 10

models = list("AIC None" = list(select = "aic", trend_type = "none", lag.max = lag.max),
              "AIC Trend"    = list(select = "aic", trend_type = "trend", lag.max = lag.max),
              "AIC Both" = list(select = "aic", trend_type = "both", lag.max = lag.max),
              "BIC None" = list(select = "bic", trend_type = "none", lag.max = lag.max),
              "BIC Trend"    = list(select = "bic", trend_type = "trend", lag.max = lag.max),
              "BIC Both" = list(select = "bic", trend_type = "both", lag.max = lag.max))

var_interest = 'logGNP'

## ------------------------------------------------------------------------
mdl_build = ModelBuildMultivariateVAR$new(data = data, var_interest = var_interest,
                                          mdl_list = models, verbose = 1)

## ------------------------------------------------------------------------
mdl_build$summarize_build()

## ------------------------------------------------------------------------
mdl_build$get_recommendations()

## ------------------------------------------------------------------------
mdl_build$build_recommended_models()

## ------------------------------------------------------------------------
# Get only user defined models
# Other options are ony recommended models (subset = 'r') or all models (subset = 'a') 
models = mdl_build$get_final_models(subset = 'u')
names(models)

## ------------------------------------------------------------------------
#### With sliding ASE = TRUE
for (name in names(models)){
  models[[name]][['sliding_ase']] = TRUE
}
  
batch_size = 38
n.ahead = 2

## ------------------------------------------------------------------------
#### With n_step.ahead = TRUE (Default)              
mdl_compare = ModelCompareMultivariateVAR$new(data = data, var_interest = var_interest,
                                              mdl_list = models, n.ahead = n.ahead, batch_size = batch_size, verbose = 1)


## ------------------------------------------------------------------------
mdl_compare$get_xIC() 

## ----fig.width=10--------------------------------------------------------
mdl_compare$plot_histogram_ases()

## ------------------------------------------------------------------------
mdl_compare$statistical_compare()  

## ----fig.width = 10------------------------------------------------------
mdl_compare$plot_simple_forecasts(zoom = 50)  ## Zoom into plot
mdl_compare$plot_simple_forecasts(lastn = TRUE, limits = FALSE, zoom = 50)
mdl_compare$plot_simple_forecasts(lastn = TRUE, limits = TRUE, zoom = 50)
mdl_compare$plot_simple_forecasts(lastn = FALSE, limits = FALSE, zoom = 50)
mdl_compare$plot_simple_forecasts(lastn = FALSE, limits = TRUE, zoom = 50)

## ----fig.width=10--------------------------------------------------------
mdl_compare$plot_batch_forecasts(only_sliding = FALSE)

## ----fig.width=10--------------------------------------------------------
mdl_compare$plot_batch_ases() 

## ------------------------------------------------------------------------
ASEs = mdl_compare$get_tabular_metrics(ases = TRUE)
print(ASEs)

## ------------------------------------------------------------------------
forecasts = mdl_compare$get_tabular_metrics(ases = FALSE)
print(forecasts)

