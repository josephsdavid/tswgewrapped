## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(tswgewrapped)

## ------------------------------------------------------------------------
file = system.file("extdata", "USeconomic.csv", package = "tswgewrapped", mustWork = TRUE)
USeconomic = read.csv(file, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
names(USeconomic) = gsub("[(|)]", "", colnames(USeconomic))
data = USeconomic

## ------------------------------------------------------------------------
# library(caret)
# 
# # Random Parallel
# model = ModelBuildNNforCaret$new(data = data, var_interest = "logGNP", m = 2,
#                                  search = 'random',
#                                  grid = NA, tuneLength = 2,
#                                  batch_size = 132, h = 2,
#                                  parallel = TRUE,
#                                  seed = 1,
#                                  verbose = 1)
# 
# model$summarize_hyperparam_results()
# model$plot_hyperparam_results()
# 
# model$summarize_best_hyperparams()
# model$summarize_build()
# 
# caret_model = model$get_final_models(subset = 'a')

## ------------------------------------------------------------------------
file = system.file("extdata", "caret_model_batch_ase.rds", package = "tswgewrapped", mustWork = TRUE)
caret_model = readRDS(file)

## ------------------------------------------------------------------------
mdl_compare = ModelCompareNNforCaret$new(data = data, var_interest = 'logGNP',
                                         mdl_list = caret_model,
                                         verbose = 1)

## ----fig.width = 8-------------------------------------------------------
p = mdl_compare$plot_boxplot_ases()

## ------------------------------------------------------------------------
mdl_compare$statistical_compare()  

## ----fig.width=8---------------------------------------------------------
# p = mdl_compare$plot_simple_forecasts()

## ----fig.width=8---------------------------------------------------------
p = mdl_compare$plot_batch_forecasts()

## ----fig.width=8---------------------------------------------------------
p = mdl_compare$plot_batch_ases() 

## ------------------------------------------------------------------------
ASEs = mdl_compare$get_tabular_metrics(ases = TRUE)
print(ASEs)

## ------------------------------------------------------------------------
forecasts = mdl_compare$get_tabular_metrics(ases = FALSE)
print(forecasts)

