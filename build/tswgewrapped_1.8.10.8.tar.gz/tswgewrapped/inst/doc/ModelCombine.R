## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(tswgewrapped)
library(dplyr)

## ------------------------------------------------------------------------
file = system.file("extdata", "USeconomic.csv", package = "tswgewrapped", mustWork = TRUE)
USeconomic = read.csv(file, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
names(USeconomic) = gsub("[(|)]", "", colnames(USeconomic))
data = USeconomic

## ------------------------------------------------------------------------
var_interest = 'logGNP'
batch_size = 120
n.ahead = 2

## ------------------------------------------------------------------------
data_train = data %>% dplyr::slice(1:(dplyr::n()-n.ahead))
data_test = data %>% dplyr::slice((dplyr::n()-n.ahead), dplyr::n())

## ------------------------------------------------------------------------
models = list("Univar A" = list(phi = 0.9, d = 1, s = 0, sliding_ase = TRUE),
              "Univar B" = list(phi = 0.9, d = 1, s = 4, sliding_ase = TRUE),
              "Univar C" = list(phi = 0.9, d = 1, s = 4, sliding_ase = FALSE)
              )

## ------------------------------------------------------------------------
mdl_compare_uni = ModelCompareUnivariate$new(data = data_train, var_interest = var_interest, mdl_list = models,
                                             n.ahead = n.ahead, batch_size = batch_size)


## ------------------------------------------------------------------------
lag.max = 10
  
models = list("AIC None" = list(select = "aic", trend_type = "none", lag.max = lag.max),
              "AIC Trend" = list(select = "aic", trend_type = "trend", lag.max = lag.max),
              "AIC Both" = list(select = "aic", trend_type = "both", lag.max = lag.max))

## ------------------------------------------------------------------------
mdl_build_var = ModelBuildMultivariateVAR$new(data = data_train, var_interest = var_interest,
                                              mdl_list = models, verbose = 0)

## ------------------------------------------------------------------------
mdl_build_var$build_recommended_models()
models = mdl_build_var$get_final_models(subset = 'r')

## ------------------------------------------------------------------------
# Setup Models to be compared with sliding ASE = TRUE
for (name in names(models)){
  models[[name]][['sliding_ase']] = TRUE
}

## ------------------------------------------------------------------------
# Initialize the ModelCompareMultivariateVAR object
mdl_compare_var = ModelCompareMultivariateVAR$new(data = data_train, var_interest = var_interest,
                                                  mdl_list = models, n.ahead = n.ahead, batch_size = batch_size, verbose = 0)

## ------------------------------------------------------------------------
# library(caret)

# # Random Parallel
# model = ModelBuildNNforCaret$new(data = data_train, var_interest = var_interest, m = 4,
#                                  search = 'random',
#                                  grid = NA, tuneLength = 2,
#                                  batch_size = batch_size, h = n.ahead,
#                                  parallel = TRUE,
#                                  seed = 1,
#                                  verbose = 1)
# 
# model$summarize_hyperparam_results()
# caret_model = model$get_final_models(subset = 'a')

## ------------------------------------------------------------------------
file_type = "train"
file_name = paste0("caret_model_", file_type, "_bs", batch_size, ".rds")
file = system.file("extdata", file_name, package = "tswgewrapped", mustWork = TRUE)
caret_model = readRDS(file)

## ------------------------------------------------------------------------
# Initialize the ModelCompareMultivariateVAR object
mdl_compare_mlp = ModelCompareNNforCaret$new(data = data_train, var_interest = var_interest,
                                             mdl_list = caret_model,
                                             verbose = 1)


## ------------------------------------------------------------------------
mdl_combine = ModelCombine$new(data = data_train, var_interest = var_interest,
                                 uni_models = mdl_compare_uni, var_models = mdl_compare_var, mlp_models = mdl_compare_mlp,
                                 verbose = 1)

## ------------------------------------------------------------------------
mdl_combine$plot_boxplot_ases()

## ------------------------------------------------------------------------
comparison = mdl_combine$statistical_compare()

## ------------------------------------------------------------------------
ases = mdl_combine$get_tabular_metrics()
ases

## ----fig.width=12, fig.height=6------------------------------------------
mdl_combine$plot_batch_ases()

## ------------------------------------------------------------------------
forecasts = mdl_combine$get_tabular_metrics(ases = FALSE)
forecasts

## ----fig.width=12, fig.height=6------------------------------------------
mdl_combine$plot_batch_forecasts()

## ------------------------------------------------------------------------
newxreg = data_test %>% dplyr::select(-!!var_interest)
mdl_combine$compute_simple_forecasts(lastn = FALSE, newxreg = newxreg)

## ------------------------------------------------------------------------
p = mdl_combine$plot_simple_forecasts(lastn = FALSE, newxreg = newxreg, zoom = 20) 

## ------------------------------------------------------------------------
mdl_combine$create_ensemble()

## ------------------------------------------------------------------------
test_var_interest = data_test[var_interest]
print("Expected Values")
print(test_var_interest)

## ------------------------------------------------------------------------
ensemble1 = mdl_combine$predict_ensemble(naive = TRUE, comb = 'median', newxreg = newxreg)
ensemble1

## ------------------------------------------------------------------------
ensemble2 = mdl_combine$predict_ensemble(naive = TRUE, comb = 'mean', newxreg = newxreg)
ensemble2

## ------------------------------------------------------------------------
ensemble3 = mdl_combine$predict_ensemble(naive = FALSE, newxreg = newxreg)
ensemble3

