## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----include=FALSE-------------------------------------------------------
## Needed otherwise vignette is not building automatically during devtools::check(), although it works ok standalone
if(!require("lattice")){
  # https://github.com/topepo/caret/issues/411#issuecomment-209973908
  install.packages("lattice", repos = "http://cran.us.r-project.org", dependencies = c("Depends", "Imports", "Suggests"))
}

## ----setup---------------------------------------------------------------
library(tswgewrapped)

## ------------------------------------------------------------------------
file = system.file("extdata", "USeconomic.csv", package = "tswgewrapped", mustWork = TRUE)
data = read.csv(file, header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
names(data) = gsub("[(|)]", "", colnames(data))

## ------------------------------------------------------------------------
lag.max = 10

models = list("AIC None" = list(select = "aic", trend_type = "none", lag.max = lag.max),
              "AIC Trend"    = list(select = "aic", trend_type = "trend", lag.max = lag.max),
              "AIC Both" = list(select = "aic", trend_type = "both", lag.max = lag.max),
              "BIC None" = list(select = "bic", trend_type = "none", lag.max = lag.max),
              "BIC Trend"    = list(select = "bic", trend_type = "trend", lag.max = lag.max),
              "BIC Both" = list(select = "bic", trend_type = "both", lag.max = lag.max))

var_interest = 'logGNP'

## ------------------------------------------------------------------------
mdl_build = ModelBuildMultivariateVAR$new(data = data, var_interest = var_interest,
                                          mdl_list = models, verbose = 1)

## ------------------------------------------------------------------------
mdl_build$summarize_build()

## ------------------------------------------------------------------------
mdl_build$get_recommendations()

## ------------------------------------------------------------------------
mdl_build$build_recommended_models()

## ------------------------------------------------------------------------
# Get only user defined models (subset = 'u')
# Other options are ony recommended models (subset = 'r') or all models (subset = 'a') 
models = mdl_build$get_final_models(subset = 'u')
print(names(models))

## ------------------------------------------------------------------------
lag.max = 10

models = list("AIC Trend"    = list(select = "aic", trend_type = "trend", season = 3, lag.max = lag.max),
              "BIC Trend"    = list(select = "bic", trend_type = "trend", season = 4, lag.max = lag.max)
              )

var_interest = 'logGNP'

## ------------------------------------------------------------------------
mdl_build = ModelBuildMultivariateVAR$new(data = data, var_interest = var_interest,
                                          mdl_list = models, verbose = 1)

## ------------------------------------------------------------------------
mdl_build$summarize_build()

## ------------------------------------------------------------------------
mdl_build$get_recommendations()

## ------------------------------------------------------------------------
mdl_build$build_recommended_models()

## ------------------------------------------------------------------------
# Get only recommended model
models = mdl_build$get_final_models(subset = 'r')
print(names(models))

## ------------------------------------------------------------------------
# Get all models
models = mdl_build$get_final_models(subset = 'a')
print(names(models))

