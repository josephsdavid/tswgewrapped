#' Pipe operator
#'
#' See \code{magrittr::\link[magrittr:pipe]{\%>\%}} for details.
#'
#' @name %>%
#' @rdname pipe
#' @keywords internal
# #' @export  ## TODO: Manually commented by Nikhil since it may be causing an issue when package is installed and users type pipe
#' @importFrom magrittr %>%
# #' @usage lhs \%>\% rhs ## TODO: Manually commented by Nikhil since it may be causing an issue when package is installed and users type pipe
NULL
